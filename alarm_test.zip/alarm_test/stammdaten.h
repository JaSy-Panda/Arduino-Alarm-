/*============================================================================================================
Descprition:  Stammdaten Aufgabe 5
Author:       Jan Syed
Date:         19.12.2022
Version:      Demo
============================================================================================================*/

int trigger = 13;
int echo = 12;

long dauer = 0;
long entfern = 0;

const int t1 = 250; //immer ms

const int buzzer = 11;

const int g_led = 9;
const int r_led = 10;


int alarm_status = 0;
int ein_status = 0;
